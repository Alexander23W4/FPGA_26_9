// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xunet_infer.h"

extern XUnet_infer_Config XUnet_infer_ConfigTable[];

#ifdef SDT
XUnet_infer_Config *XUnet_infer_LookupConfig(UINTPTR BaseAddress) {
	XUnet_infer_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XUnet_infer_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XUnet_infer_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XUnet_infer_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XUnet_infer_Initialize(XUnet_infer *InstancePtr, UINTPTR BaseAddress) {
	XUnet_infer_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XUnet_infer_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XUnet_infer_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XUnet_infer_Config *XUnet_infer_LookupConfig(u16 DeviceId) {
	XUnet_infer_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XUNET_INFER_NUM_INSTANCES; Index++) {
		if (XUnet_infer_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XUnet_infer_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XUnet_infer_Initialize(XUnet_infer *InstancePtr, u16 DeviceId) {
	XUnet_infer_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XUnet_infer_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XUnet_infer_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

