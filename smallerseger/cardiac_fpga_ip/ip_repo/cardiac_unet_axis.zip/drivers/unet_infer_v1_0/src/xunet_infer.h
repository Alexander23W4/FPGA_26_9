// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XUNET_INFER_H
#define XUNET_INFER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xunet_infer_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XUnet_infer_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XUnet_infer;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XUnet_infer_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XUnet_infer_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XUnet_infer_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XUnet_infer_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XUnet_infer_Initialize(XUnet_infer *InstancePtr, UINTPTR BaseAddress);
XUnet_infer_Config* XUnet_infer_LookupConfig(UINTPTR BaseAddress);
#else
int XUnet_infer_Initialize(XUnet_infer *InstancePtr, u16 DeviceId);
XUnet_infer_Config* XUnet_infer_LookupConfig(u16 DeviceId);
#endif
int XUnet_infer_CfgInitialize(XUnet_infer *InstancePtr, XUnet_infer_Config *ConfigPtr);
#else
int XUnet_infer_Initialize(XUnet_infer *InstancePtr, const char* InstanceName);
int XUnet_infer_Release(XUnet_infer *InstancePtr);
#endif

void XUnet_infer_Start(XUnet_infer *InstancePtr);
u32 XUnet_infer_IsDone(XUnet_infer *InstancePtr);
u32 XUnet_infer_IsIdle(XUnet_infer *InstancePtr);
u32 XUnet_infer_IsReady(XUnet_infer *InstancePtr);
void XUnet_infer_EnableAutoRestart(XUnet_infer *InstancePtr);
void XUnet_infer_DisableAutoRestart(XUnet_infer *InstancePtr);

void XUnet_infer_Set_weights(XUnet_infer *InstancePtr, u64 Data);
u64 XUnet_infer_Get_weights(XUnet_infer *InstancePtr);
void XUnet_infer_Set_params(XUnet_infer *InstancePtr, u64 Data);
u64 XUnet_infer_Get_params(XUnet_infer *InstancePtr);
void XUnet_infer_Set_workspace(XUnet_infer *InstancePtr, u64 Data);
u64 XUnet_infer_Get_workspace(XUnet_infer *InstancePtr);

void XUnet_infer_InterruptGlobalEnable(XUnet_infer *InstancePtr);
void XUnet_infer_InterruptGlobalDisable(XUnet_infer *InstancePtr);
void XUnet_infer_InterruptEnable(XUnet_infer *InstancePtr, u32 Mask);
void XUnet_infer_InterruptDisable(XUnet_infer *InstancePtr, u32 Mask);
void XUnet_infer_InterruptClear(XUnet_infer *InstancePtr, u32 Mask);
u32 XUnet_infer_InterruptGetEnabled(XUnet_infer *InstancePtr);
u32 XUnet_infer_InterruptGetStatus(XUnet_infer *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
