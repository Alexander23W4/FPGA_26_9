// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xunet_infer.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XUnet_infer_CfgInitialize(XUnet_infer *InstancePtr, XUnet_infer_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XUnet_infer_Start(XUnet_infer *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XUnet_infer_IsDone(XUnet_infer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XUnet_infer_IsIdle(XUnet_infer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XUnet_infer_IsReady(XUnet_infer *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XUnet_infer_EnableAutoRestart(XUnet_infer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XUnet_infer_DisableAutoRestart(XUnet_infer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_AP_CTRL, 0);
}

void XUnet_infer_Set_weights(XUnet_infer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WEIGHTS_DATA, (u32)(Data));
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WEIGHTS_DATA + 4, (u32)(Data >> 32));
}

u64 XUnet_infer_Get_weights(XUnet_infer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WEIGHTS_DATA);
    Data += (u64)XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WEIGHTS_DATA + 4) << 32;
    return Data;
}

void XUnet_infer_Set_params(XUnet_infer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_PARAMS_DATA, (u32)(Data));
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_PARAMS_DATA + 4, (u32)(Data >> 32));
}

u64 XUnet_infer_Get_params(XUnet_infer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_PARAMS_DATA);
    Data += (u64)XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_PARAMS_DATA + 4) << 32;
    return Data;
}

void XUnet_infer_Set_workspace(XUnet_infer *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WORKSPACE_DATA, (u32)(Data));
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WORKSPACE_DATA + 4, (u32)(Data >> 32));
}

u64 XUnet_infer_Get_workspace(XUnet_infer *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WORKSPACE_DATA);
    Data += (u64)XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_WORKSPACE_DATA + 4) << 32;
    return Data;
}

void XUnet_infer_InterruptGlobalEnable(XUnet_infer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_GIE, 1);
}

void XUnet_infer_InterruptGlobalDisable(XUnet_infer *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_GIE, 0);
}

void XUnet_infer_InterruptEnable(XUnet_infer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_IER);
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_IER, Register | Mask);
}

void XUnet_infer_InterruptDisable(XUnet_infer *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_IER);
    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XUnet_infer_InterruptClear(XUnet_infer *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XUnet_infer_WriteReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_ISR, Mask);
}

u32 XUnet_infer_InterruptGetEnabled(XUnet_infer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_IER);
}

u32 XUnet_infer_InterruptGetStatus(XUnet_infer *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XUnet_infer_ReadReg(InstancePtr->Control_BaseAddress, XUNET_INFER_CONTROL_ADDR_ISR);
}

